$source = $args[0]
$destination = 'miners.zip'
Start-BitsTransfer -Source $source -Destination $destination -DisplayName 'miners.zip'